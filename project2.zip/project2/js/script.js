
document.addEventListener('DOMContentLoaded', () => {
    const bookBtn = document.querySelector('.button');
    if (bookBtn) {
        bookBtn.addEventListener('click', (e) => {
            alert('Thank you for choosing Hole in One! Booking page will open.');
        });
    }
});